{
    'name': 'Custom Clearance Management',
    'version': '1.0',
    'complexity': 'normal',
    'category': 'Tech/Clearance Logistic',
    'description': """Module for Custom clearance management, It gives the clearance user the ablitiy to:
			* create Clearance & bill of lading  requesition.
			* insert the Bill of lading,IM,Invoices .
			* followup the process and workflow  of custom clearance.
			* Create purchase order from selected quotation. 
		   """,
    'author': 'IT Dept. @ SEDC',
    'website': 'http://www.sedc.sd.com',
    'images' : ['images/clearance_logo.jpg'],
    'depends': ['base','purchase'],
    'data': [
        'security/custom_clearance_security.xml',
        'security/ir.model.access.csv',
        'view/custom_clearance_view.xml',
        'view/purchase_order_custom_view.xml',
        'view/res_partner_custom_view.xml',
        'view/account_config_view.xml',
        'report/report_view.xml' ,
        'report/template/header_footer_template.xml',
        'report/template/clearance_request_templet.xml',
        'report/template/financial_claim_templet.xml',
        'data/custom_clearance_data.xml'
            
    ],
   
    'installable': True,
    'auto_install': False,
}


