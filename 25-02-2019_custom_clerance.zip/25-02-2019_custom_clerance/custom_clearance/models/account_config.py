from openerp import api, models, fields

class account_config(models.Model):
    _name = "account.config"
    _description="account and jurnal account"


    name = fields.Char('Account name', required = True)
    account_id = fields.Many2one('account.account', 'Account',  required = True)
    journal_id = fields.Many2one('account.journal', string='Journal', required = True)
    date = fields.Date('Date', default=fields.datetime.now(), readonly=True)
    actives = fields.Boolean('Active', readonly=True)
    anayletc_account_id = fields.Many2one('account.analytic.account', 'Analytic Account')

   
    @api.multi
    def change_active(self):
        record = self.env['account.config'].search([('actives','=', True)])
        if record and len(record) >0:
            for act in record:
                act.actives = False


    @api.model
    def create(self, vals):
        result = super(account_config, self).create(vals)
        self.change_active()

        record_ids = self.env['account.config'].search([])[-1]
        last_id = record_ids.id
        record_ids.actives = True
        return result
