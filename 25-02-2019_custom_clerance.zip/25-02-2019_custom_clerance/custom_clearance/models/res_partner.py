from openerp import api, models, fields

class res_partner(models.Model):
	_inherit = 'res.partner'
	_description = 'Add partner type'

	savior_clearance = fields.Boolean('Custom Broker', default=False)