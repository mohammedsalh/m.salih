import time
import math
import openerp.addons.decimal_precision as dp
from datetime import date, datetime
from openerp import models, fields, api
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, DEFAULT_SERVER_DATETIME_FORMAT , image_colorize, image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError

class clearance_requisition(models.Model):
    _name = "clearance.requisition"
    _description="Clearance Requisition"
    _rec_name = "ref"
    _inherit = ['mail.thread']

    ref = fields.Char('Requisition ID', compute='_code_automated',  size=64, readonly=True)
    po_no = fields.Char('Purchase  Order No')
    currency_id = fields.Many2one('res.currency','Currency', required=False)
    requisition_type = fields.Selection([('sedc','SEDC'),('other','Other')], string='Request from', required=True, default=None)
    
    date = fields.Date('Requisition Date', default=fields.datetime.now())
    department_id = fields.Many2one('hr.department', 'Department' )
    user = fields.Many2one('res.users', 'Responsible', readonly=False, default=lambda self: self.env.user)
    
    bill_lading_no = fields.Char('Bill of Lading No', size=128, required=False)
    invoice_no = fields.Char('Invoice No', size=128, required=False )
    certificate_origin_no = fields.Char('Certificate of Origin No', size=128, required=False)

    requisition_lines = fields.One2many('clearance.requisition.line', 'requisition_id', 'Clearance Requisition Lines' )
    
    partner_id = fields.Many2one('res.partner', 'Shipper' )
    notify_party = fields.Many2one('res.partner', 'Notify Party' )
    

    departure_port = fields.Char('Port Of Departure', size=64 )
    departure_date = fields.Date('Date of Departure' )
    expected_date = fields.Date('Expected Date of Arrival' )
    custom_broker = fields.Many2one('res.partner', 'Custom Broker', required=False)

    date_approve = fields.Date('Date Approved', readonly=1, select=True, help="Date on which Clearance order has been approved")
    notes = fields.Text('Notes')
    company_id = fields.Many2one('res.company', 'Company', required=False )        
    state =fields.Selection([('draft', 'Draft'),
                            ('confirmed','Confirmed'),
                            ('approve','Approve'),
                            ('create_invoice','Create Voucher'),
                            ('done', 'Done'),
                            ('cancel', 'Cancel'),], default='draft',)

    place_id = fields.Many2one('clearance.place', 'Clearance Place')
    account_config_id = fields.Many2one('account.config', 'Account', compute='_defult_read', readonly=False)
    Clearance_costs = fields.Float("Total Cost", compute="_total_invoice", required = False)
    invoice_ids = fields.One2many('clearance.invoices', 'requisition_id', store = True, string='Invoices', write=['custom_clearance.group_cs','custom_clearance.group_co'])
    inv_stae = fields.Char('Invoice State', compute='_defult_read')
    claim_ref_vou = fields.Many2one('account.voucher','Claim Reference', compute='_defult_read')


    @api.multi
    def action_draft(self):
        self.write({'state':'draft'})
        return True

    @api.multi
    def action_confirmed(self):
        self.write({'state':'confirmed'})
        return True

    @api.multi
    def action_approve(self):
        self.write({'state':'approve'})
        return True

    @api.multi
    def action_create_invoice(self):
        if len(self.env['account.voucher'].search([('reference','=',self.ref)])) > 0:
            raise UserError('Constraint Error: The Voucher is already Created! ')
        else:
            if self.custom_broker.id and self.currency_id.id and self.account_config_id.id:
                self.creat_clearance_voucher()
                self.write({'state':'create_invoice'})
                return True
            else:
                raise UserError("Enter of Customs Clearance or account or Currency...!")
        

    @api.multi
    def action_done(self):
        account_ivo_obj = self.env['account.voucher'].search([('reference','=',self.ref)])
        if account_ivo_obj.state == 'posted':
            self.write({'state':'done'})
            return True
        else:
            raise UserError("Whait Voucher Posted...!")

    @api.multi
    def action_cancel(self):
        for rec in self:
            record = self.env['account.voucher'].search([('clearance_requisition_id','=',rec.id)])
            if record.state =='draft':
                record.unlink()
                self.write({'state':'cancel'})
                return True
            else:
                raise UserError("Associated with a financial claim under confirming..!")
   
    


    @api.multi
    def creat_clearance_voucher(self):
        account_ivo_obj = self.env['account.voucher']
        invoice_line_ids = []
        for inv in self.invoice_ids:
            if inv.cost > 0.0:
                values = {
                    #'product_id':self.po_no,
                    'name':inv.name.name,
                    'quantity':1,
                    'account_id':self.account_config_id.account_id.id,
                    'account_analytic_id': self.account_config_id.anayletc_account_id.id,
                    'price_unit':inv.cost,
                    }
                invoice_line_ids.append((0,0,values))
        new_account_invoice_obj = {
            'clearance_requisition_id':self.id,
            'reference':self.ref,
            'company_id':self.company_id,
            'currency_id':self.currency_id.id,
            'partner_id':self.custom_broker.id,
            'journal_id':self.account_config_id.journal_id.id,
            'date':self.date,
            'account_id':self.custom_broker.property_account_payable_id.id,
            'voucher_type' :'purchase',
            'line_ids':invoice_line_ids
            }
        record = account_ivo_obj.create(new_account_invoice_obj)
        return record

   
    @api.depends('invoice_ids')
    def _total_invoice(self):
        self.Clearance_costs = 0.0
        if self.invoice_ids:
                self.Clearance_costs = sum(map(float, self.invoice_ids.mapped('cost'))) 
                
    @api.multi
    def _code_automated(self):
        for code in self:
            code.ref = 'CCR' +'-'+ str(code.id+1)

    
    def _defult_read(self):
        account_ivo_obj = self.env['account.voucher']
        invoice_stat = account_ivo_obj.search([('reference','=',self.ref)])
        self.inv_stae = invoice_stat.state
        self.claim_ref_vou = invoice_stat.id

        config_id = self.env['account.config'].search([('actives','=', True)])
        self.account_config_id = config_id.id
        
    @api.multi
    def _track_subtype(self, init_values):
        if 'state' in init_values:
            return 'custom_clearance_1.mt_clearance_state_change'
        return super(clearance_requisition, self)._track_subtype(init_values)
        
class clearance_requisition_line(models.Model):

    _name = "clearance.requisition.line"
    _description="Clearance Requisition Line"
    _rec_name = 'product_id'

    product_id = fields.Many2one('product.product', 'Description of Goods', required=True )
    product_qty = fields.Float('Quantity',required=True )
    product_uom = fields.Many2one('product.uom', 'Product UOM', compute='_automated_uom', required=True )
    net_weight =fields.Float('Net Weight', required=False )
    net_weight_uom = fields.Many2one('product.uom', ' Net Weight UOM', required=False)
    gross_weight =fields.Float('Gross Weight', required=False )
    gross_weight_uom = fields.Many2one('product.uom', ' Gross Weight UOM', required=False )
    packages_no =fields.Integer('No of Packages',required=False )
    packages_uom = fields.Many2one('product.uom', 'Packages UOM', required=False )
    requisition_id = fields.Many2one('clearance.requisition','Clearance Requisition', ondelete='cascade' )
    country_origin = fields.Many2one('res.country', 'Country Of Origin' )
    description = fields.Text('Description')


    @api.multi
    @api.depends('product_id')
    def _automated_uom(self):
      for line in self:
        if line.product_id :
          line.product_uom = line.product_id.product_tmpl_id.uom_id.id


class ClearanceInvoices(models.Model):
    """docstring for ClearanceInvoices"""
    _name = 'clearance.invoices'
    _description = 'Invoice detals'

    name = fields.Many2one('clearance.stage', string="Stage", required=True)
    cost = fields.Float('Stage Cost')
    requisition_id = fields.Many2one('clearance.requisition', 'Requisition')
    
        
class clearance_stage(models.Model):
    _name = 'clearance.stage'
    _description = 'Clearance Stages'

    name = fields.Char('name',size=32,required=True )
    stage_no = fields.Integer('Stage Number',size=32)
    clearance_place_id = fields.Many2one('clearance.place', 'Clearance Place', required=False)
    #active = fields.Boolean('Active' )

class ClearancePlace(models.Model):
    _name = 'clearance.place'
    _description = 'Clearance Place'

    name = fields.Char('Name', size=32 , required=True)
    code = fields.Char('Code')


    