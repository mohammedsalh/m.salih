import time
import math
import openerp.addons.decimal_precision as dp
from datetime import date, datetime
from openerp import models, fields, api
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, DEFAULT_SERVER_DATETIME_FORMAT , image_colorize, image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError


class PurchaseOrder(models.Model):
	_name = "purchase.order"
	_inherit = "purchase.order"
	_description = "Custom Purchase Order"


	customs = fields.Boolean("Customs", default=False)

	@api.multi
	def creat_new_custom_clearance(self):
		customs_clearance_obj = self.env['clearance.requisition']
		custom_src = []
		#for purchase in self:
		for line in self.order_line:
			values = {
			'net_weight_uom':line.product_uom.id,
			'product_id':line.product_id.id,
			'product_qty':line.product_qty,
			}
			custom_src.append((0,0,values))
		new_customs_clearance_obj = customs_clearance_obj.create({
			'po_no':self.name,
			'currency_id':self.currency_id.id,
			'Clearance_costs': 0.0,
			'date':self.date_order,
			'user':self.create_uid.id,
			'requisition_type':'sedc',
			'requisition_lines':custom_src
			})



	@api.multi
	def button_confirm(self):
		
		result = super(PurchaseOrder, self).button_confirm()
		if self.customs == True:
			self.creat_new_custom_clearance()
		else:
			return result
