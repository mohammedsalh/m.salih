from openerp import api, fields, models
from openerp.tools.float_utils import float_compare


class AccountVoucher(models.Model):
	_inherit = 'account.voucher'


	clearance_requisition_id = fields.Many2one('clearance.requisition', string='Add Clearance Requisition')

	@api.multi
	def proforma_voucher(self):
		if self.clearance_requisition_id:
			self.clearance_requisition_id.state = 'done'
		return super(AccountVoucher, self).proforma_voucher()

