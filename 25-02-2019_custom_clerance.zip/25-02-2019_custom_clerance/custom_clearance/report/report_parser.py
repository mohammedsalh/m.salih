from openerp import models, api, _
from datetime import datetime 

class ClearanceRequest(models.AbstractModel):
	_name = 'report.custom_clearance.root_clearance_templet'


	@api.multi
	def render_html(self, data=None):
		print "Render method is called for template.."
		report_object = self.env['report']
		report = report_object._get_report_from_name('custom_clearance.root_clearance_templet')
		customs = self.env['clearance.requisition'].browse(self.ids)
		docargs = {
	      'doc_ids':self.ids,
	      'doc_model':report.model,
	      'data':data,
	      'docs':customs, 
	      'datetime':datetime,
	      'company': self.env.user.company_id
	    }

		return report_object.render('custom_clearance.root_clearance_templet', docargs)


class FinancialClaim(models.AbstractModel):

	_name = 'report.custom_clearance.root_financial_claim_templet'


	@api.multi
	def render_html(self, data=None):
		print "Render method is called for template.."
		report_object = self.env['report']
		report = report_object._get_report_from_name('custom_clearance.root_financial_claim_templet')
		customs = self.env['clearance.requisition'].browse(self.ids)
		docargs = {
		    'doc_ids':self.ids,
		    'doc_model':report.model,
		    'data':data,
		    'docs':customs,
		    'datetime':datetime,
		    'company': self.env.user.company_id
		}

		return report_object.render('custom_clearance.root_financial_claim_templet', docargs)
